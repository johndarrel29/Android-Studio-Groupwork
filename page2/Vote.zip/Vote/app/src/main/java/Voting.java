public class Voting {
}
